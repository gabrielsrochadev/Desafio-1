compras = []
total_bruto = 0.0
total_final = 0.0
total_descontos = 0.0

while True:
    valor = float(input("Digite o valor da compra (ou 0 para encerrar): "))
    
    if valor == 0:
        break
        
    idade = int(input("Digite a idade do cliente: "))
    
    if valor < 0 or idade < 0:
        print("Aviso: O valor ou a idade não podem ser negativos. Tente novamente.")
        continue
        
    valor_com_desconto = valor
    
    if idade >= 65:
        valor_com_desconto = valor_com_desconto * 0.80
        
    if valor_com_desconto > 100:
        valor_com_desconto = valor_com_desconto * 0.90
        
    desconto_concedido = valor - valor_com_desconto
    
    compras.append(valor_com_desconto)
    
    total_bruto += valor
    total_final += valor_com_desconto
    total_descontos += desconto_concedido
    
    print(f"Valor final: R$ {valor_com_desconto:.2f}\n")

print("\n--- RESUMO DO DIA ---")
print(f"Quantidade de compras registradas: {len(compras)}")
print(f"Total bruto: R$ {total_bruto:.2f}")
print(f"Total de descontos concedidos: R$ {total_descontos:.2f}")
print(f"Total final: R$ {total_final:.2f}")